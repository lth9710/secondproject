package com.project2;

public class PrintTot2 extends Thread{
	
	@Override
	public void run() {

		try {
		System.out.println(" ��                                                ��");
		sleep(300);
		System.out.println(" ��                                                ��");
		sleep(300);
		System.out.println(" ��                                                ��");
		sleep(300);
		System.out.println(" ��             �̿����ּż� �����մϴ�            ��");
		sleep(300);
		System.out.println(" ��                                                ��");
		sleep(300);
		System.out.println(" �ˢˢˢˢˢˢˢˢˢˢˢˢˢˢˢˢˢˢˢˢˢˢˢˢˢ�");
		sleep(300);
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		
	}

	
	
}
