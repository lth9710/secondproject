package com.project2;

public class StartScreen extends Thread{


	@Override
	public void run() {




		try {

			System.out.println("1");
			sleep(50);
			System.out.println("1");
			sleep(50);
			System.out.println("1");
			sleep(50);
			System.out.println("1");
			sleep(50);
			System.out.println("1");
			sleep(50);
			System.out.println("1");
			sleep(50);
			System.out.println("1");
			sleep(50);
			System.out.println("1");
			sleep(50);
			System.out.println("1");
			sleep(50);
			System.out.println("1");
			sleep(50);
			System.out.println("1");
			sleep(50);
			System.out.println("1");
			sleep(50);
			System.out.println("1");
			sleep(50);
			System.out.println("1");
			sleep(50);
			System.out.println("1");
			sleep(50);
			




		} catch (Exception e) {
			// TODO: handle exception
		}


	}

}
