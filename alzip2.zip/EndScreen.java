package com.project2;

public class EndScreen extends Thread{


	@Override
	public void run() {




		try {                                       		                                           		                                           		         
			System.out.println("				                                           		                                           		                                           		          ");sleep(300);
			System.out.println("				                                           		                                           		                                           		          ");sleep(300);
			System.out.println("				                                           		                                           		                                           		          ");sleep(300);
			System.out.println("				                                           		                                           		                                           		          ");sleep(300);
			System.out.println("				                                           		                                           		                                           		          ");sleep(300);
			System.out.println("                                                                                 ��������������                                                               ");sleep(300);
			System.out.println("                                                                                 ��                      ��                                                               ");sleep(300);
			System.out.println("                                                                                 ��                      ��                                                               ");sleep(300);
			System.out.println("                                          WXeeeeeeeeeeeeeezW                     ��   �� å ������ ��!   ��                                                               ");sleep(300);
			System.out.println("                                    5eeeeeeeeeeeeG#eeeeeeeee#       K,           ��                      ��                                     	   	                  ");sleep(300);
			System.out.println("                                ,eeeeGeEezEeeezKy9XDKD59  eeeezeeGee5X9e9        ��                      ��                                     		                  ");sleep(300);
			System.out.println("                             9eeeeu99Dz9zXeeeeeG#99GED   W9EeX   E,X    eeG      ������    �������                                   	 	                      ");sleep(1500);
            System.out.println("                          EeeeeeeeeE yuEeeeeeE#eeGeW , EeeeeE   eeKeeEeGzeee9            ��   ��                                                   	 	                      \n"+
			"                        eeeeeeeeeezeGee##5yyyXEuu zD   eEeey   eeXee eeeeE uez           ��  ��                                                   		                      \n"+
			"                      ee9#GeGEeeeeee ,zE#EeeeeeGXuWeeeeeeee   ,eeee eeeeeu#uXeX         �� ��                                                         		                  \n"+
			"                    yeeKeeeeeeEeeeeeEEeeeee5  , zee9,yeee5  5 9eGeeeeeeE eDeGGKE       ���                                                        		                  \n"+
			"                    eeeeEGeeGeee#9GeeGe#X9eeeeeeeX#eeeu     e ee# eeeE KEeD9DXE#      ��                                                       		                  \n"+
			"                   eeee#eeeGeeeeeeeeeeeeeeezu               #z ee eeeye#eee 9zze                                                               		                  \n"+
			"                  eeGeeeEEeeeeeEeeeeeey                      e De eeGz99eXe 5X5eE                                                              		                  \n"+
			"                 eeyeeeeXeeGeeeeeW                            ee#WeeXXeeE e#KezEW                                                              		                  \n"+
			"                 eeXGDeeeeee#                                  9eeez GeeeyXE u9Xe                                                                 		                  \n"+
			"                XeeeEGeeeez           ,                         e5e9eGz95u,z5De e                                                               		                  \n"+
			"                ,eGeeeee#                                        eee9XX#Xzee9 u9u                                                               		                  \n"+
			"                 ee#eeee  uK ,                                    eeeeWD5EeEWKWe                                                               		                  \n"+
			"                 ee#EeeG ,K                                        eEzGe D K ueW                                                              		                      \n"+
			"                 9eyeeeu                       yX5Wy,Kee    ,   ,   uDeeEeD# Ee                                                                		                  \n"+
			"                  e5eee K, uXXWzEeGee        Dez5u                   ze  e ,De                                                                		                      \n"+
			"                  e9ee  ,uK ,      ,u                                 #KWe9y                                                                   		                  \n"+
			"                    ze eezKeeeeeeeeeeeeeeeeKeeeeeeD55WD#Geeeeee5GeeeeeeeeKDKzDe                                                                		                  \n"+
			"                    Xeee            eeeeeeeeu                eeE#Xy,  eG , eD e                                                                		                  \n"+
			"                    eu              e      E                 e        5   uW  #                                                                		                  \n"+
			"                   ueee             e      E                 e        u  9e                                                                    		                  \n"+
			"                    eee             #       u              eee   ,        ee  u                                                                		                  \n"+
			"                    eeeKuWyuu ,Xeee#K       ,eee9W ee ,uKXzz             Xy ,                                                                 		                  \n"+
			"                     ee                                                  eXKWu                                                                		                      \n"+
			"                              ,                                         u5  X                                                                 		                      \n"+
			"                     e               u                                     u                                                                  		                      \n"+
			"                     e     ,      ,E                                                                                                          		                      \n"+
			"                     eu          yeE     y   e9,                       5ez                                                                    		                      \n"+
			"                     e5            eeeeeeeeeXeWu                                                                                              		                      \n"+
			"                     KG             W#DKW                                D                                                                    		                      \n"+
			"                      e  ,            ye                                 D                                                                     		                      \n"+
			"                      G                                                 ,y                                                                    		                      \n"+
			"                      yy                                               y                                                                      		                      \n"+
			"                       e         eeeeeeeeeee5y,We,                     y                                                                      		                      \n"+
			"                       e         #u           ,,y                     e                                                                      		                      \n"+
			"                        e             GeeeGeu                        eG                                                                      		                      \n"+
			"                        ee     ,                                   ueX                                                                       		                      \n"+
			"                         ee    ,,  ,                 u             u                                                                         		                      \n"+
			"                          #ey    ,    ,           ,, , ,         #eee9                                                                        		                      \n"+
			"                            EeE        ,               ,     WKuXeeee                                                                          		                  \n"+
			"                              ue5e                         Ke5Xeeeee                                                                              		              \n"+
			"                           DeeeE5zee             5EWKu,,   eeGee9e,eeee#                         ��                         ��    ��    		                      \n"+
			"                            yeeEu zeeeeeezy#555eee       Xee, eWX     Keeeu            �ǢǢǢ�  ��        ��      ��    �ǢǢǢ� ��    ��      ��  �ǢǢ�  ��	          \n"+
			"                            eeeeeuX9G  uKyW  e5u        Key   zyu EzG    ,eeE               ��   �Ǣ�     �Ǣ�     ��     �ǢǢ�  �Ǣ�  ��      ��  ��      ��	          \n"+
			"                          eeK   eE9Ee , eeeGeWe        ue Xeeee#eDEeGW uee ,e              ��    ��      ��  ��    �Ǣ�  ��    �� ��    ��      ��  ��      �Ǣ�	      \n"+
			"                         Ge GyeGeGe e,ueee   eeG    XDKeeeeee9XGKeeDXe9Ee   e            ��      ��     ��    ��   ��     �ǢǢ�  ��    ��      ��  ��      ��		      \n"+
			"                         #eee5eEeyGeezDeD eeey  e 5e  eXeezeW 5  u #eXeeWK, ee                         ��      ��  ��       ��    ��    �ǢǢ�  ��  �ǢǢ�  ��		      \n"+
			"                         eeeeeeeeeeeeez  Deeee   z#  eeEXGzy D KuuW ee#EK W ye             �ǢǢǢ�                         �ǢǢǢ�               	 	          \n"+
			"                         eeeeezeeeeeee   eEEKee    5eEyXzD, E  K5zXz#y E uK  e             ��    ��                         ��    ��              		                  \n"+
			"                        eeeeEeD9GeeeeeK XeXyuee   eeKDGeXGueee#e9EEGe Ke 5#K Ee            �ǢǢǢ�                         �ǢǢǢ�                                              \n"+
		/*"                        eGEeeGDE##DGeee eE5X#9e  eeEueee#eeWeeKGyz# eWW#5DDuuXe                                                                                          \n"+
		"                       XeXeeeE9EE9XGeee eEDDE#e#eeeEeeeeeezeeeGDeDe X#E uuXuuue5                                                                                         \n"+
		"                       e#WeeDeDEDy9E#eeDeWW EX#eeEEuGD9555 ,  5 Eey9 #Xy5X5X  K#                                                                                         \n"+
		"                       e De#GE5eGzeE#9eeeKKW#yeezz ,Xez e5XGu 5 u  z uuu# uy  uD                                                                                         \n"+
		"                      We yE ey#G9#ezDDXGee # KeeKy,zeEKDe EXu W  W X XXK55,   uW,                                                                                        \n"+
		"                      uy  G e59ee#5 u yyee D eeX5 #K9KKXX,Xu  uu y X,u  ,u      ,                                                                                        \n"+
		"                        zze yG eXE K  u Kee KeGWK Xe5uy5,yz  ,   u , u u                                                                                                 \n"+
		"                         ,e  5 e , Ku    W eeeeW uEeKX5X eK         u                                                                                                    \n"+
		"                          #u,    u  u,     ye       #,eD e           ,                                                                                                   \n"+
		"                                ,   u      5e                                                                                                                            \n"+
		"                                     u                                                                                                                                   \n"+
		"                                                                                                                                                                         \n"+*/
			"                                                                                                                                                                     ");
		
			
			
			
			




		} catch (Exception e) {
			// TODO: handle exception
		}

	}

}
